package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.databinding.ActivityRegisterBinding;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding registerBinding;
    DbHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerBinding = ActivityRegisterBinding.inflate(getLayoutInflater());
        View view = registerBinding.getRoot();
        setContentView(view);
        setContentView(R.layout.activity_register);
        databaseHelper = new DbHelper(this);
    }

    public void registerUser(View view){
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues userData = new ContentValues();
        String name = registerBinding.etName.getText().toString();
        String identification = registerBinding.etId.toString();
        String email = registerBinding.etRegisterEmail.toString();
        String password = registerBinding.etRegisterPassword.toString();
        userData.put("name",name);
        userData.put("identification", identification);
        userData.put("email", email);
        userData.put("password", password);

        long newUser = db.insert("users",null,userData);
        Toast.makeText(this, "" + newUser, Toast.LENGTH_SHORT).show();
    }
}